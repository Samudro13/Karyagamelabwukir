<?php $__env->startSection('content'); ?>
<!-- Content Header (Page header) -->
<div class="content-header">
	<div class="container-fluid">
		<div class="row mb-2">
			<div class="col-sm-6">
				<h1 class="m-0 text-dark">Mata Pelajaran	</h1>
			</div><!-- /.col -->
			<div class="col-sm-6">
				<ol class="breadcrumb float-sm-right">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>">Dashboard</a></li>
					<li class="breadcrumb-item active">Mata Pelajaran</li>
				</ol>
			</div><!-- /.col -->
		</div><!-- /.row -->
	</div><!-- /.container-fluid -->
</div>
<!-- /.content-header -->

<?php $__env->startSection('addCss'); ?>
<link rel="stylesheet" href="<?php echo e(asset ('css/dataTables.bootstrap4.min.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('addJavascript'); ?>
<script src="<?php echo e(asset('js/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/dataTables.bootstrap4.min.js')); ?>"></script>
<script>
	$(function(){
		$("#data-table").DataTable()})
</script>	

<script src="<?php echo e(asset('js/sweetalert.min.js')); ?>"></script>

<script>
	confirmDelete = function(button){
		var url = $(button).data('url');
		swal({
			'title': 'Konfirmasi Hapus',
			'text':'Apakah Kamu Yakin Ingin Menghapus Data Ini?',
			'dangerMode': true,
			'buttons': true
		}).then(function(value) {
			if (value){
				window.location = url;
			}
		})
}
</script>
<?php $__env->stopSection(); ?>

<!-- Main content -->
<div class="content">
	<div class="container-fluid">
	
		
        <div class="card">
			<div class="card-header text-right">
				<a href="<?php echo e(route('createMapel')); ?>" class="btn btn-primary " role="button">Tambah Mata Pelajaran</a>
			</div>
            <div class= "card-body">
				<table class="table table-bordered mb-0" id="data-table">
					<thead>
						<tr>
							<th>No.</th>
							<th>Nama Pelajaran</th>
							<th>Nama Jurusan</th>
							<th>Deskripsi</th>
							<th>Aksi</th>
						</tr>
					</thead>
					<tbody>
						<?php $__currentLoopData = $mata_pelajarans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mata_pelajaran): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<tr>
							<td> <?php echo e($loop->index + 1); ?></td>
							<td> <?php echo e($mata_pelajaran->nama); ?></td>
							<td> <?php echo e($mata_pelajaran->jurusan ? $mata_pelajaran->jurusan->nama : '-'); ?></td>
							<td> <?php echo e($mata_pelajaran->deskripsi); ?></td>
							<td>
								<a href="<?php echo e(route('editMapel', ['id' => $mata_pelajaran->id])); ?>" class="btn btn-warning btn-sm" role="button">Edit</a>
								<a onclick="confirmDelete(this)" data-url ="<?php echo e(route('deleteMapel', ['id'=> $mata_pelajaran->id])); ?>" class="btn btn-danger btn-sm" role="button">Hapus</a>
							</td>
						</tr>
							
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</tbody>

				</table>
                
            </div>

        </div>

	</div><!-- /.container-fluid -->
</div>
<!-- /.content -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\karyagamelab\resources\views/mata_pelajaran/index.blade.php ENDPATH**/ ?>