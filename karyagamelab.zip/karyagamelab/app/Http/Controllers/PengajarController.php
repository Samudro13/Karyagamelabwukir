<?php

namespace App\Http\Controllers;

use App\Pengajar;
use Illuminate\Http\Request;

class PengajarController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $pengajars = Pengajar::all();
        return view('pengajar.index',  [
            'pengajars' => $pengajars
        ]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('pengajar.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $validatedData = validator($request->all(),[
            'nama' => 'required|string|max:255',
            'kelas' => 'required|string|max:255',
            'deskripsi' => 'required|string',
        ])->validate();

        $pengajar = new Pengajar($validatedData);
        $pengajar->save();

        return redirect(route('daftarPengajar'));
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Pengajar  $pengajar
     * @return \Illuminate\Http\Response
     */
    public function show(Pengajar $pengajar)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Pengajar  $pengajar
     * @return \Illuminate\Http\Response
     */
    public function edit(Pengajar $pengajar)
    {
        return view('pengajar.edit',[
            'pengajar' => $pengajar
        ]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Pengajar  $pengajar
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Pengajar $pengajar)
    {
        $validatedData =  validator($request->all(),[
            'nama' => 'required|string|max:255',
            'kelas' => 'required|string|max:255',
            'deskripsi' => 'required|string',
        ])->validate();

        $pengajar->nama = $validatedData['nama'];
        $pengajar->deskripsi =$validatedData['deskripsi'];
        $pengajar->save();

        return redirect(route('daftarPengajar'));
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Pengajar  $pengajar
     * @return \Illuminate\Http\Response
     */
    public function destroy(Pengajar $pengajar)
    {
        $pengajar->delete();
        return redirect(route('daftarPengajar'));
    }
}
